# Final Project Overview
​
For my final project I recreated the original videogame, Pong. I spent a lot of time getting it to where it is and I'm proud to share my work. I wish I had tackled different aspects of my project earlier so that I could've had more time to fine tune and improve upon my project. It was fun making my own game (even if I was just ripping off the OG) and I enjoyed watching my work become interactive.


Video Demo:
​
[![Pong Demo](http://imgur.com/a/Ytt6a)](https://www.youtube.com/watch?v=Fwo24Q8fYXg "Pong Demo")

[Build Process Paper](https://github.com/ISmckay/ISmckay.github.io/blob/docs/mckay_projectpaper.pdf)
